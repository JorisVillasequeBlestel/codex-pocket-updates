#!/bin/zsh
set -u

if (( $# != 3 )); then
  print -u2 "Usage: $0 /Applications/App.app configuration.json support-directory"
  exit 64
fi

readonly APP="$1"
readonly CONFIGURATION="$2"
readonly SUPPORT_DIRECTORY="$3"
readonly REQUIREMENT='anchor apple generic and identifier "com.jorisvillaseque.codexpocket.companion" and certificate leaf[subject.OU] = "M32VRN7YT6"'
readonly BACKUP_DIRECTORY="$SUPPORT_DIRECTORY/last-known-good"
readonly BACKUP_APP="$BACKUP_DIRECTORY/Codex Pocket Companion.app"
readonly FAILED_DIRECTORY="$SUPPORT_DIRECTORY/failed-updates"
readonly HEALTH_FILE="$SUPPORT_DIRECTORY/update-health.json"
readonly CANDIDATE_BUILD_FILE="$SUPPORT_DIRECTORY/update-candidate-build"
readonly CANDIDATE_STARTED_FILE="$SUPPORT_DIRECTORY/update-candidate-started"
readonly CANDIDATE_FAILURES_FILE="$SUPPORT_DIRECTORY/update-candidate-failures"
readonly APP_EXECUTABLE="$APP/Contents/MacOS/Codex Pocket Companion"
readonly CHECK_INTERVAL="${CODEX_POCKET_MONITOR_INTERVAL:-15}"
readonly HEALTH_TIMEOUT="${CODEX_POCKET_MONITOR_HEALTH_TIMEOUT:-180}"
readonly MAX_FAILURES="${CODEX_POCKET_MONITOR_MAX_FAILURES:-3}"
readonly RUN_ONCE="${CODEX_POCKET_MONITOR_RUN_ONCE:-0}"

if [[ -z "$APP" || -z "$SUPPORT_DIRECTORY" || "$APP" == "/" || "$SUPPORT_DIRECTORY" == "/" ]]; then
  print -u2 "Refus de superviser un chemin non sûr."
  exit 65
fi

verify_app() {
  local app_path="$1"
  [[ -d "$app_path" ]] || return 1
  /usr/bin/codesign --verify --deep --strict --requirement "$REQUIREMENT" "$app_path" >/dev/null 2>&1
}

app_build() {
  /usr/libexec/PlistBuddy -c 'Print :CFBundleVersion' "$1/Contents/Info.plist" 2>/dev/null
}

write_state() {
  local destination="$1"
  local value="$2"
  local temporary="${destination}.tmp"
  /usr/bin/printf '%s\n' "$value" > "$temporary"
  /bin/chmod 600 "$temporary"
  /bin/mv -f "$temporary" "$destination"
}

read_state() {
  local source="$1"
  [[ -f "$source" ]] || return 1
  /bin/cat "$source" 2>/dev/null
}

clear_candidate_state() {
  /bin/rm -f "$CANDIDATE_BUILD_FILE" "$CANDIDATE_STARTED_FILE" "$CANDIDATE_FAILURES_FILE"
}

is_running() {
  /usr/bin/pgrep -f -x "$APP_EXECUTABLE" >/dev/null 2>&1
}

launch_app() {
  if ! is_running; then
    /usr/bin/open -gj "$APP" >/dev/null 2>&1 || true
  fi
}

snapshot_current_as_good() {
  local current_build="$1"
  local staging="$BACKUP_DIRECTORY/Codex Pocket Companion.staging.app"
  local previous="$BACKUP_DIRECTORY/Codex Pocket Companion.previous.app"

  /bin/mkdir -p "$BACKUP_DIRECTORY"
  /bin/chmod 700 "$BACKUP_DIRECTORY"
  /bin/rm -rf "$staging" "$previous"
  /usr/bin/ditto "$APP" "$staging" || return 1
  verify_app "$staging" || {
    /bin/rm -rf "$staging"
    return 1
  }

  if [[ -d "$BACKUP_APP" ]]; then
    /bin/mv "$BACKUP_APP" "$previous" || {
      /bin/rm -rf "$staging"
      return 1
    }
  fi
  if ! /bin/mv "$staging" "$BACKUP_APP"; then
    [[ -d "$previous" ]] && /bin/mv "$previous" "$BACKUP_APP"
    return 1
  fi
  /bin/rm -rf "$previous"
  write_state "$BACKUP_DIRECTORY/build" "$current_build"
}

restore_last_known_good() {
  verify_app "$BACKUP_APP" || return 1

  local backup_build
  backup_build="$(app_build "$BACKUP_APP")" || return 1
  local timestamp
  timestamp="$(/bin/date +%Y%m%d-%H%M%S)"
  local restore_stage="${APP}.codex-pocket-restore"
  local failed_app="$FAILED_DIRECTORY/Codex Pocket Companion.failed-${timestamp}.app"

  /bin/mkdir -p "$FAILED_DIRECTORY"
  /bin/chmod 700 "$FAILED_DIRECTORY"
  /bin/rm -rf "$restore_stage"
  /usr/bin/ditto "$BACKUP_APP" "$restore_stage" || return 1
  verify_app "$restore_stage" || {
    /bin/rm -rf "$restore_stage"
    return 1
  }

  /usr/bin/pkill -f -x "$APP_EXECUTABLE" >/dev/null 2>&1 || true
  /bin/sleep 1
  if [[ -d "$APP" ]]; then
    /bin/mv "$APP" "$failed_app" || {
      /bin/rm -rf "$restore_stage"
      return 1
    }
  fi
  if ! /bin/mv "$restore_stage" "$APP"; then
    [[ -d "$failed_app" ]] && /bin/mv "$failed_app" "$APP"
    return 1
  fi

  clear_candidate_state
  write_state "$BACKUP_DIRECTORY/build" "$backup_build"
  launch_app
}

health_confirms_build() {
  local expected_build="$1"
  [[ -f "$HEALTH_FILE" ]] || return 1
  local health_build
  health_build="$(/usr/bin/plutil -extract build raw -o - "$HEALTH_FILE" 2>/dev/null)" || return 1
  [[ "$health_build" == "$expected_build" ]] || return 1
  /usr/bin/plutil -extract healthyAt raw -o - "$HEALTH_FILE" >/dev/null 2>&1
}

monitor_once() {
  /bin/mkdir -p "$SUPPORT_DIRECTORY"
  /bin/chmod 700 "$SUPPORT_DIRECTORY"

  if ! /usr/bin/grep -Eq '"enabled"[[:space:]]*:[[:space:]]*true' "$CONFIGURATION" 2>/dev/null; then
    return 0
  fi

  if ! verify_app "$APP"; then
    restore_last_known_good || true
    return 0
  fi

  local current_build
  current_build="$(app_build "$APP")" || {
    restore_last_known_good || true
    return 0
  }

  if ! verify_app "$BACKUP_APP"; then
    snapshot_current_as_good "$current_build" || return 0
    clear_candidate_state
    launch_app
    return 0
  fi

  local backup_build
  backup_build="$(app_build "$BACKUP_APP")" || return 0
  if [[ "$current_build" == "$backup_build" ]]; then
    clear_candidate_state
    launch_app
    return 0
  fi

  if health_confirms_build "$current_build"; then
    snapshot_current_as_good "$current_build" && clear_candidate_state
    launch_app
    return 0
  fi

  local now
  now="$(/bin/date +%s)"
  local candidate_build
  candidate_build="$(read_state "$CANDIDATE_BUILD_FILE" 2>/dev/null || true)"
  if [[ "$candidate_build" != "$current_build" ]]; then
    write_state "$CANDIDATE_BUILD_FILE" "$current_build"
    write_state "$CANDIDATE_STARTED_FILE" "$now"
    write_state "$CANDIDATE_FAILURES_FILE" "0"
  fi

  local started
  started="$(read_state "$CANDIDATE_STARTED_FILE" 2>/dev/null || print "$now")"
  local elapsed=$(( now - started ))
  if is_running; then
    if (( elapsed >= HEALTH_TIMEOUT )); then
      restore_last_known_good || true
    fi
    return 0
  fi

  local failures
  failures="$(read_state "$CANDIDATE_FAILURES_FILE" 2>/dev/null || print 0)"
  failures=$(( failures + 1 ))
  write_state "$CANDIDATE_FAILURES_FILE" "$failures"
  if (( failures >= MAX_FAILURES )); then
    restore_last_known_good || true
    return 0
  fi
  launch_app
}

while true; do
  monitor_once
  if [[ "$RUN_ONCE" == "1" ]]; then
    exit 0
  fi
  /bin/sleep "$CHECK_INTERVAL"
done
