import http from "node:http";
import { execFile, spawn } from "node:child_process";
import { createInterface } from "node:readline";
import { randomBytes, randomUUID } from "node:crypto";
import { promises as fs } from "node:fs";
import { createConnection } from "node:net";
import os from "node:os";
import path from "node:path";
import { promisify } from "node:util";

const VERSION = "0.2.4";
const MAX_IPC_FRAME_BYTES = 16 * 1024 * 1024;
const ALL_THREAD_SOURCES = [
  "cli",
  "vscode",
  "exec",
  "appServer",
  "unknown",
];

const configDirectory = process.env.CODEX_POCKET_CONFIG_DIR
  ? path.resolve(process.env.CODEX_POCKET_CONFIG_DIR)
  : path.join(os.homedir(), "Library", "Application Support", "CodexPocket");
const configPath = path.join(configDirectory, "bridge.json");
const codexStatePath = process.env.CODEX_POCKET_CODEX_STATE_PATH
  ? path.resolve(process.env.CODEX_POCKET_CODEX_STATE_PATH)
  : path.join(os.homedir(), ".codex", ".codex-global-state.json");
const codexLogsPath = process.env.CODEX_POCKET_LOGS_DB_PATH
  ? path.resolve(process.env.CODEX_POCKET_LOGS_DB_PATH)
  : path.join(os.homedir(), ".codex", "logs_2.sqlite");
const codexHomePath = process.env.CODEX_POCKET_CODEX_HOME
  ? path.resolve(process.env.CODEX_POCKET_CODEX_HOME)
  : path.join(os.homedir(), ".codex");
const codexDesktopIPCPath = process.env.CODEX_POCKET_DESKTOP_IPC_PATH
  ? path.resolve(process.env.CODEX_POCKET_DESKTOP_IPC_PATH)
  : path.join(codexHomePath, "ipc", "ipc.sock");
const execFileAsync = promisify(execFile);

class CodexDesktopIPC {
  constructor(socketPath = codexDesktopIPCPath) {
    this.socketPath = socketPath;
    this.socket = null;
    this.clientId = null;
    this.buffer = Buffer.alloc(0);
    this.pending = new Map();
    this.connecting = null;
    this.stopping = false;
  }

  async forwardTurn(threadId, turnStartParams, { steer = false } = {}) {
    if (typeof threadId !== "string" || !threadId) return { handled: false };
    const method = steer ? "thread-follower-steer-turn" : "thread-follower-start-turn";
    const params = steer
      ? {
        conversationId: threadId,
        input: turnStartParams.input,
        restoreMessage: null,
        serviceTier: turnStartParams.serviceTier ?? null,
        attachments: turnStartParams.attachments ?? [],
        clientUserMessageId: turnStartParams.clientUserMessageId ?? null,
        additionalContext: turnStartParams.additionalContext ?? null,
      }
      : { conversationId: threadId, turnStartParams };
    try {
      await this.connect();
      const response = await this.sendRequest(method, params, 1, 30_000);
      const routed = response?.result;
      if (routed?.method !== method) {
        throw new Error("Codex Desktop a renvoyé une réponse incohérente");
      }
      return { handled: true, result: routed?.result?.result ?? routed?.result ?? {} };
    } catch (error) {
      if (this.isUnavailable(error)) return { handled: false };
      throw error;
    }
  }

  isUnavailable(error) {
    const message = (error instanceof Error ? error.message : String(error)).toLowerCase();
    return ["ENOENT", "ECONNREFUSED", "ECONNRESET", "EPIPE"].includes(error?.code)
      || message.includes("no-client-found")
      || message.includes("target app window is not ready")
      || message.includes("thread stream owner became unavailable")
      || message.includes("conversation is not being streamed");
  }

  async connect() {
    if (this.socket?.writable && this.clientId) return;
    if (this.connecting) return this.connecting;
    this.connecting = this.open().finally(() => {
      this.connecting = null;
    });
    return this.connecting;
  }

  async open() {
    const socketInfo = await fs.lstat(this.socketPath);
    const directoryInfo = await fs.lstat(path.dirname(this.socketPath));
    const uid = process.getuid?.();
    if (!socketInfo.isSocket()
      || !directoryInfo.isDirectory()
      || (uid !== undefined && (socketInfo.uid !== uid || directoryInfo.uid !== uid))
      || (directoryInfo.mode & 0o022) !== 0) {
      throw new Error("Le canal local Codex n’est pas sécurisé");
    }

    const socket = createConnection({ path: this.socketPath });
    await new Promise((resolve, reject) => {
      const onError = (error) => {
        socket.off("connect", onConnect);
        reject(error);
      };
      const onConnect = () => {
        socket.off("error", onError);
        resolve();
      };
      socket.once("error", onError);
      socket.once("connect", onConnect);
    });
    if (this.stopping) {
      socket.destroy();
      throw new Error("Le canal local Codex est arrêté");
    }

    this.socket = socket;
    this.buffer = Buffer.alloc(0);
    socket.on("data", (chunk) => this.handleData(chunk));
    socket.on("error", () => {});
    socket.on("close", () => this.handleClose(socket));
    let initialized;
    try {
      initialized = await this.sendRequest(
        "initialize",
        { clientType: "codex-pocket-companion" },
        0,
        5_000,
        true,
      );
    } catch (error) {
      socket.destroy();
      throw error;
    }
    const clientId = initialized?.result?.clientId;
    if (typeof clientId !== "string" || !clientId) {
      socket.destroy();
      throw new Error("Codex Desktop a refusé le canal local");
    }
    this.clientId = clientId;
  }

  sendRequest(method, params, version, timeoutMs, allowInitializing = false) {
    if (!this.socket?.writable || (!allowInitializing && !this.clientId)) {
      return Promise.reject(new Error("Le canal local Codex n’est pas connecté"));
    }
    const requestId = randomUUID();
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(requestId);
        reject(new Error(`Délai dépassé pour le rafraîchissement Codex (${method})`));
      }, timeoutMs);
      this.pending.set(requestId, { resolve, reject, timer });
      try {
        this.sendFrame({
          type: "request",
          requestId,
          sourceClientId: this.clientId || "initializing-client",
          version,
          method,
          params,
          timeoutMs,
        });
      } catch (error) {
        clearTimeout(timer);
        this.pending.delete(requestId);
        reject(error);
      }
    });
  }

  sendFrame(message) {
    if (!this.socket?.writable) throw new Error("Le canal local Codex est fermé");
    const payload = Buffer.from(JSON.stringify(message), "utf8");
    if (payload.length > MAX_IPC_FRAME_BYTES) throw new Error("Message IPC Codex trop volumineux");
    const header = Buffer.allocUnsafe(4);
    header.writeUInt32LE(payload.length, 0);
    this.socket.write(Buffer.concat([header, payload]));
  }

  handleData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (this.buffer.length >= 4) {
      const length = this.buffer.readUInt32LE(0);
      if (length === 0 || length > MAX_IPC_FRAME_BYTES) {
        this.socket?.destroy();
        return;
      }
      if (this.buffer.length < length + 4) return;
      const payload = this.buffer.subarray(4, length + 4);
      this.buffer = this.buffer.subarray(length + 4);
      let message;
      try {
        message = JSON.parse(payload.toString("utf8"));
      } catch {
        this.socket?.destroy();
        return;
      }
      this.handleMessage(message);
    }
  }

  handleMessage(message) {
    if (message.type === "client-discovery-request") {
      this.sendFrame({
        type: "client-discovery-response",
        requestId: message.requestId,
        response: { canHandle: false },
      });
      return;
    }
    if (message.type !== "response") return;
    const pending = this.pending.get(message.requestId);
    if (!pending) return;
    clearTimeout(pending.timer);
    this.pending.delete(message.requestId);
    if (message.resultType === "error") pending.reject(new Error(message.error || "Erreur IPC Codex"));
    else pending.resolve(message);
  }

  handleClose(socket) {
    if (this.socket !== socket) return;
    this.socket = null;
    this.clientId = null;
    this.buffer = Buffer.alloc(0);
    for (const { reject, timer } of this.pending.values()) {
      clearTimeout(timer);
      reject(new Error("Le canal local Codex s’est fermé"));
    }
    this.pending.clear();
  }

  stop() {
    this.stopping = true;
    this.socket?.destroy();
    this.socket = null;
  }
}

function sqliteString(value) {
  return `'${String(value).replaceAll("'", "''")}'`;
}

async function findCodexStateDatabase() {
  if (process.env.CODEX_POCKET_CODEX_DB_PATH) {
    return path.resolve(process.env.CODEX_POCKET_CODEX_DB_PATH);
  }
  let entries;
  try {
    entries = await fs.readdir(codexHomePath, { withFileTypes: true });
  } catch (error) {
    if (error.code === "ENOENT") return null;
    throw error;
  }
  const databases = entries
    .filter((entry) => entry.isFile() && /^state_\d+\.sqlite$/.test(entry.name))
    .sort((left, right) => Number(right.name.match(/\d+/)?.[0] || 0) - Number(left.name.match(/\d+/)?.[0] || 0));
  return databases[0] ? path.join(codexHomePath, databases[0].name) : null;
}

async function excludeArchivedThreadIds(threadIds) {
  if (threadIds.length === 0) return [];
  const databasePath = await findCodexStateDatabase();
  if (!databasePath) throw new Error("L’index local Codex est introuvable");
  const archived = new Set();
  for (let index = 0; index < threadIds.length; index += 400) {
    const batch = threadIds.slice(index, index + 400);
    const identifiers = batch.map(sqliteString).join(",");
    const { stdout } = await execFileAsync(
      "/usr/bin/sqlite3",
      ["-readonly", "-json", databasePath, `SELECT id FROM threads WHERE archived = 1 AND id IN (${identifiers});`],
      { timeout: 3_000, maxBuffer: 512 * 1024 },
    );
    const rows = stdout.trim() ? JSON.parse(stdout) : [];
    for (const row of rows) archived.add(row.id);
  }
  return threadIds.filter((threadId) => !archived.has(threadId));
}

async function migratePocketThreadSources() {
  if (process.env.CODEX_POCKET_DISABLE_THREAD_SOURCE_MIGRATION === "1") {
    return { migrated: 0, skipped: "disabled" };
  }
  const databasePath = await findCodexStateDatabase();
  if (!databasePath) return { migrated: 0, skipped: "database_missing" };

  const query = "SELECT id, rollout_path FROM threads WHERE thread_source = 'appServer' ORDER BY updated_at DESC;";
  let rows;
  try {
    const { stdout } = await execFileAsync(
      "/usr/bin/sqlite3",
      ["-readonly", "-json", databasePath, query],
      { timeout: 5_000, maxBuffer: 2 * 1024 * 1024 },
    );
    rows = stdout.trim() ? JSON.parse(stdout) : [];
  } catch (error) {
    return { migrated: 0, skipped: "database_unavailable", error: error.message };
  }

  const sessionsRoot = path.join(codexHomePath, "sessions");
  const candidates = [];
  for (const row of rows) {
    if (!/^[0-9a-f-]{36}$/i.test(row.id || "")) continue;
    const rolloutPath = path.resolve(row.rollout_path || "");
    if (!rolloutPath.startsWith(`${sessionsRoot}${path.sep}`)) continue;
    try {
      const contents = await fs.readFile(rolloutPath, "utf8");
      const newline = contents.indexOf("\n");
      const firstLine = newline >= 0 ? contents.slice(0, newline) : contents;
      const metadata = JSON.parse(firstLine);
      if (metadata.type !== "session_meta" || metadata.payload?.originator !== "codex_pocket_bridge") continue;
      candidates.push({ id: row.id, rolloutPath, contents, metadata, newline });
    } catch {
      // A malformed or concurrently unavailable rollout is left untouched.
    }
  }
  if (candidates.length === 0) return { migrated: 0 };

  const stamp = new Date().toISOString().replaceAll(":", "-").replaceAll(".", "-");
  const backupDirectory = path.join(configDirectory, "backups", `thread-source-${stamp}`);
  await fs.mkdir(backupDirectory, { recursive: true, mode: 0o700 });
  const databaseBackupPath = path.join(backupDirectory, path.basename(databasePath));
  await execFileAsync(
    "/usr/bin/sqlite3",
    [databasePath, `.backup ${sqliteString(databaseBackupPath)}`],
    { timeout: 10_000, maxBuffer: 512 * 1024 },
  );
  await fs.chmod(databaseBackupPath, 0o600);

  for (const candidate of candidates) {
    const backupPath = path.join(backupDirectory, `${candidate.id}.jsonl`);
    await fs.copyFile(candidate.rolloutPath, backupPath);
    await fs.chmod(backupPath, 0o600);
    candidate.metadata.payload.thread_source = "user";
    const replacement = `${JSON.stringify(candidate.metadata)}${candidate.newline >= 0 ? candidate.contents.slice(candidate.newline) : "\n"}`;
    const temporaryPath = `${candidate.rolloutPath}.codex-pocket-${process.pid}.tmp`;
    await fs.writeFile(temporaryPath, replacement, { mode: 0o600 });
    await fs.rename(temporaryPath, candidate.rolloutPath);
  }

  const identifiers = candidates.map((candidate) => sqliteString(candidate.id)).join(",");
  await execFileAsync(
    "/usr/bin/sqlite3",
    [databasePath, `PRAGMA busy_timeout=5000; BEGIN IMMEDIATE; UPDATE threads SET thread_source = 'user' WHERE thread_source = 'appServer' AND id IN (${identifiers}); COMMIT;`],
    { timeout: 10_000, maxBuffer: 512 * 1024 },
  );
  return { migrated: candidates.length, backupDirectory };
}

async function readDesktopActiveThreadIds() {
  const query = `
    WITH ranked AS (
      SELECT
        thread_id,
        feedback_log_body,
        ROW_NUMBER() OVER (
          PARTITION BY thread_id
          ORDER BY ts DESC, ts_nanos DESC, id DESC
        ) AS row_number
      FROM logs
      WHERE target = 'codex_core::session::turn'
        AND feedback_log_body LIKE '%post sampling token usage%'
        AND thread_id IS NOT NULL
        AND ts > strftime('%s', 'now') - 600
    )
    SELECT thread_id
    FROM ranked
    WHERE row_number = 1
      AND feedback_log_body LIKE '%needs_follow_up=true%';
  `;
  try {
    const { stdout } = await execFileAsync(
      "/usr/bin/sqlite3",
      ["-readonly", "-json", codexLogsPath, query],
      { timeout: 2_000, maxBuffer: 512 * 1024 },
    );
    const rows = stdout.trim() ? JSON.parse(stdout) : [];
    return new Set(rows.map((row) => row.thread_id).filter(Boolean));
  } catch {
    return new Set();
  }
}

function withActivityStatus(thread, activeThreadIds) {
  if (!thread?.id || !activeThreadIds.has(thread.id)) return thread;
  return { ...thread, status: { ...(thread.status || {}), type: "active" } };
}

function isTailscaleIPv4(address) {
  if (typeof address !== "string") return false;
  const parts = address.split(".").map(Number);
  return parts.length === 4
    && parts.every((part) => Number.isInteger(part) && part >= 0 && part <= 255)
    && parts[0] === 100
    && parts[1] >= 64
    && parts[1] <= 127;
}

function isAllowedBindHost(host) {
  return host === "127.0.0.1" || host === "::1" || isTailscaleIPv4(host);
}

async function loadConfig() {
  await fs.mkdir(configDirectory, { recursive: true, mode: 0o700 });
  let current = {};
  try {
    current = JSON.parse(await fs.readFile(configPath, "utf8"));
  } catch (error) {
    if (error.code !== "ENOENT") throw error;
  }

  const documents = path.join(os.homedir(), "Documents");
  const developer = path.join(os.homedir(), "Developer");
  const bindHost = process.env.CODEX_POCKET_BIND_HOST || current.bindHost || "127.0.0.1";
  if (!isAllowedBindHost(bindHost)) {
    throw new Error("Le pont Codex refuse toute écoute hors de l’interface Tailscale ou loopback");
  }
  const config = {
    token: current.token || randomBytes(32).toString("base64url"),
    port: Number(process.env.CODEX_POCKET_PORT || current.port || 47321),
    bindHost,
    allowedRoots: Array.isArray(current.allowedRoots)
      ? current.allowedRoots
      : [documents, developer],
    favorites: Array.isArray(current.favorites) ? current.favorites : [],
  };
  await fs.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
  await fs.chmod(configPath, 0o600);
  return config;
}

class CodexAppServer {
  constructor(desktopIPC = new CodexDesktopIPC()) {
    this.desktopIPC = desktopIPC;
    this.child = null;
    this.nextId = 1;
    this.pending = new Map();
    this.listeners = new Set();
    this.serverRequests = new Map();
    this.activeThreadIds = new Set();
    this.activeTurnIds = new Map();
    this.desktopTurnPollers = new Map();
    this.ready = false;
    this.lastError = null;
    this.stopping = false;
    this.restartTimer = null;
  }

  async start() {
    if (this.child) return;
    const bundledCodex = "/Applications/ChatGPT.app/Contents/Resources/codex";
    const codexBin = process.env.CODEX_BIN || bundledCodex;
    const args = ["app-server", "--stdio"];
    this.child = spawn(codexBin, args, {
      env: {
        ...process.env,
        PATH: `/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:${process.env.PATH || ""}`,
      },
      stdio: ["pipe", "pipe", "pipe"],
    });

    const stdout = createInterface({ input: this.child.stdout });
    stdout.on("line", (line) => this.handleLine(line));
    this.child.stderr.on("data", (chunk) => {
      const text = chunk.toString().trim();
      if (text) this.lastError = text.slice(-2000);
    });
    this.child.once("error", (error) => this.handleExit(error));
    this.child.once("exit", (code, signal) => {
      this.handleExit(new Error(`Codex app-server stopped (${code ?? signal ?? "unknown"})`));
    });

    await this.request("initialize", {
      clientInfo: {
        name: "codex_pocket_bridge",
        title: "Codex Pocket",
        version: VERSION,
      },
      capabilities: {
        experimentalApi: true,
      },
    });
    this.notify("initialized", {});
    this.ready = true;
    this.lastError = null;
    this.broadcast({ kind: "bridge", state: "ready" });
  }

  stop() {
    this.stopping = true;
    if (this.restartTimer) clearTimeout(this.restartTimer);
    this.child?.kill("SIGTERM");
    this.child = null;
    for (const poller of this.desktopTurnPollers.values()) clearTimeout(poller.timer);
    this.desktopTurnPollers.clear();
    this.desktopIPC.stop();
  }

  handleExit(error) {
    if (!this.child && this.stopping) return;
    this.ready = false;
    this.lastError = error.message;
    this.child = null;
    for (const { reject, timer } of this.pending.values()) {
      clearTimeout(timer);
      reject(error);
    }
    this.pending.clear();
    this.broadcast({ kind: "bridge", state: "codexUnavailable", message: error.message });
    if (!this.stopping) {
      this.restartTimer = setTimeout(() => this.start().catch(() => {}), 1500);
    }
  }

  handleLine(line) {
    let message;
    try {
      message = JSON.parse(line);
    } catch {
      this.lastError = `Invalid JSON from Codex: ${line.slice(0, 300)}`;
      return;
    }

    if (message.id !== undefined && message.method) {
      const key = String(message.id);
      this.serverRequests.set(key, message);
      this.broadcast({
        kind: "serverRequest",
        requestId: key,
        method: message.method,
        params: message.params || {},
      });
      return;
    }

    if (message.id !== undefined) {
      const pending = this.pending.get(String(message.id));
      if (!pending) return;
      clearTimeout(pending.timer);
      this.pending.delete(String(message.id));
      if (message.error) {
        const error = new Error(message.error.message || "Codex request failed");
        error.details = message.error;
        pending.reject(error);
      } else {
        pending.resolve(message.result ?? {});
      }
      return;
    }

    if (message.method) {
      const threadId = message.params?.threadId;
      if (threadId && message.method === "turn/started") {
        this.activeThreadIds.add(threadId);
        const turnId = message.params?.turn?.id;
        if (turnId) this.activeTurnIds.set(threadId, turnId);
      }
      if (threadId && message.method === "turn/completed") {
        this.clearDesktopTurnTracking(threadId);
        this.activeThreadIds.delete(threadId);
        this.activeTurnIds.delete(threadId);
      }
      if (threadId && message.method === "thread/status/changed") {
        if (message.params?.status?.type === "active") this.activeThreadIds.add(threadId);
        else {
          this.activeThreadIds.delete(threadId);
          this.activeTurnIds.delete(threadId);
        }
      }
      this.broadcast({ kind: "notification", method: message.method, params: message.params || {} });
    }
  }

  request(method, params = {}, timeoutMs = 30_000) {
    if (!this.child?.stdin?.writable) {
      return Promise.reject(new Error("Codex app-server is not running"));
    }
    const id = String(this.nextId++);
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`Codex request timed out: ${method}`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer, method });
      this.child.stdin.write(`${JSON.stringify({ method, id: Number(id), params })}\n`);
    });
  }

  trackDesktopTurn(threadId, turn) {
    const turnId = turn?.id || this.activeTurnIds.get(threadId) || randomUUID();
    this.clearDesktopTurnTracking(threadId);
    this.activeThreadIds.add(threadId);
    this.activeTurnIds.set(threadId, turnId);
    const startedTurn = { id: turnId, status: turn?.status || "inProgress", items: turn?.items || [] };
    this.broadcast({
      kind: "notification",
      method: "turn/started",
      params: { threadId, turn: startedTurn },
    });
    const poller = { turnId, timer: null, failures: 0 };
    this.desktopTurnPollers.set(threadId, poller);
    this.scheduleDesktopTurnPoll(threadId, poller);
    return startedTurn;
  }

  scheduleDesktopTurnPoll(threadId, poller) {
    poller.timer = setTimeout(async () => {
      if (this.desktopTurnPollers.get(threadId) !== poller || this.stopping) return;
      try {
        const result = await this.request("thread/read", { threadId, includeTurns: true }, 8_000);
        const thread = result.thread || result;
        const turns = Array.isArray(thread?.turns) ? thread.turns : [];
        const turn = turns.find((entry) => entry?.id === poller.turnId) || turns.at(-1);
        const status = typeof turn?.status === "string" ? turn.status.toLowerCase() : "";
        const threadStatus = typeof thread?.status?.type === "string" ? thread.status.type.toLowerCase() : "";
        const completed = ["completed", "failed", "cancelled", "canceled", "interrupted"].includes(status)
          || (threadStatus && threadStatus !== "active" && turns.some((entry) => entry?.id === poller.turnId));
        if (completed) {
          this.clearDesktopTurnTracking(threadId);
          this.activeThreadIds.delete(threadId);
          this.activeTurnIds.delete(threadId);
          this.broadcast({
            kind: "notification",
            method: "turn/completed",
            params: { threadId, turn: turn || { id: poller.turnId, status: "completed", items: [] } },
          });
          return;
        }
        poller.failures = 0;
      } catch {
        poller.failures += 1;
      }
      if (poller.failures < 120) this.scheduleDesktopTurnPoll(threadId, poller);
      else this.clearDesktopTurnTracking(threadId);
    }, 1_000);
    poller.timer.unref?.();
  }

  clearDesktopTurnTracking(threadId) {
    const poller = this.desktopTurnPollers.get(threadId);
    if (poller?.timer) clearTimeout(poller.timer);
    this.desktopTurnPollers.delete(threadId);
  }

  notify(method, params = {}) {
    if (!this.child?.stdin?.writable) return;
    this.child.stdin.write(`${JSON.stringify({ method, params })}\n`);
  }

  respond(requestId, result) {
    const original = this.serverRequests.get(String(requestId));
    if (!original) throw new Error("Approval request is no longer pending");
    this.serverRequests.delete(String(requestId));
    this.child.stdin.write(`${JSON.stringify({ id: Number(requestId), result })}\n`);
    return original;
  }

  subscribe(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  broadcast(event) {
    for (const listener of this.listeners) listener(event);
  }
}

function sendJSON(response, status, payload) {
  const body = JSON.stringify(payload);
  response.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
  });
  response.end(body);
}

async function readJSON(request) {
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > 1_048_576) throw new Error("Request body is too large");
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  return JSON.parse(Buffer.concat(chunks).toString("utf8"));
}

function isAuthorized(request, config) {
  const header = request.headers.authorization || "";
  return header === `Bearer ${config.token}`;
}

function safePath(candidate, allowedRoots) {
  if (typeof candidate !== "string" || !path.isAbsolute(candidate)) return false;
  const resolved = path.resolve(candidate);
  return allowedRoots.some((root) => {
    const relative = path.relative(path.resolve(root), resolved);
    return relative === "" || (!relative.startsWith("..") && !path.isAbsolute(relative));
  });
}

function matchRoute(pathname, expression) {
  const match = pathname.match(expression);
  return match ? match.slice(1).map(decodeURIComponent) : null;
}

function activeTurnIdFromThread(thread) {
  if (!thread || !Array.isArray(thread.turns)) return null;
  const activeStatuses = new Set(["active", "inprogress", "in_progress", "running"]);
  for (let index = thread.turns.length - 1; index >= 0; index -= 1) {
    const turn = thread.turns[index];
    const status = typeof turn?.status === "string" ? turn.status.toLowerCase() : "";
    if (turn?.id && activeStatuses.has(status)) return turn.id;
  }
  return null;
}

function normalizeModel(model) {
  const efforts = Array.isArray(model?.supportedReasoningEfforts)
    ? model.supportedReasoningEfforts.map((entry) => ({
      effort: typeof entry === "string" ? entry : entry?.reasoningEffort,
      description: typeof entry === "string" ? "" : entry?.description || "",
    })).filter((entry) => typeof entry.effort === "string" && entry.effort)
    : [];
  return {
    id: model.id,
    model: model.model || model.id,
    displayName: model.displayName || model.id,
    description: model.description || "",
    isDefault: Boolean(model.isDefault),
    defaultReasoningEffort: model.defaultReasoningEffort || efforts[0]?.effort || null,
    supportedReasoningEfforts: efforts,
  };
}

async function capabilitiesFor(codex, config, threadId) {
  let thread = null;
  if (threadId) {
    const result = await codex.request("thread/read", { threadId, includeTurns: false }, 8_000);
    thread = result.thread || result;
  }
  const registry = await loadCodexProjectRegistry();
  const allowedRoots = [...config.allowedRoots, ...registry.projects.map((project) => project.cwd)];
  const cwd = thread?.cwd;
  if (threadId && !safePath(cwd, allowedRoots)) {
    throw new Error("Le dossier de cette discussion n’est pas autorisé");
  }

  const safeRequest = async (method, params) => {
    try {
      return await codex.request(method, params, 12_000);
    } catch {
      return { data: [] };
    }
  };
  const [modelsResult, modesResult, skillsResult, appsResult] = await Promise.all([
    safeRequest("model/list", { limit: 100, includeHidden: false }),
    safeRequest("collaborationMode/list", {}),
    cwd ? safeRequest("skills/list", { cwds: [cwd], forceReload: false }) : { data: [] },
    threadId ? safeRequest("app/list", { threadId, limit: 100, forceRefetch: false }) : { data: [] },
  ]);
  const skills = (skillsResult.data || []).flatMap((entry) => entry.skills || [])
    .filter((skill) => skill?.enabled && typeof skill.path === "string")
    .map((skill) => ({
      name: skill.name,
      path: skill.path,
      description: skill.interface?.shortDescription || skill.shortDescription || skill.description || "",
    }));
  const apps = (appsResult.data || [])
    .filter((app) => app?.isEnabled !== false && app?.isAccessible !== false)
    .map((app) => ({ id: app.id, name: app.name, description: app.description || "" }));
  return {
    cwd: cwd || null,
    models: (modelsResult.data || []).filter((model) => !model.hidden).map(normalizeModel),
    collaborationModes: (modesResult.data || [])
      .filter((mode) => typeof mode?.name === "string" && mode.mode && mode.model)
      .map((mode) => ({
      name: mode.name,
      mode: mode.mode || null,
      model: mode.model || null,
      reasoningEffort: mode.reasoning_effort || null,
      })),
    skills,
    apps,
  };
}

function buildTurnInput(body, capabilities) {
  const selectedSkills = Array.isArray(body.skillPaths) ? body.skillPaths : [];
  const selectedApps = Array.isArray(body.appIds) ? body.appIds : [];
  const skillsByPath = new Map(capabilities.skills.map((skill) => [skill.path, skill]));
  const appsById = new Map(capabilities.apps.map((app) => [app.id, app]));
  const invalidSkill = selectedSkills.find((skillPath) => !skillsByPath.has(skillPath));
  const invalidApp = selectedApps.find((appId) => !appsById.has(appId));
  if (invalidSkill || invalidApp) throw new Error("Un outil sélectionné n’est pas disponible sur ce Mac");

  const appMentions = selectedApps.map((appId) => {
    const app = appsById.get(appId);
    return `[$${app.name}](app://${app.id})`;
  });
  const text = [...appMentions, body.text.trim()].join(appMentions.length ? "\n\n" : "");
  return [
    { type: "text", text, text_elements: [] },
    ...selectedSkills.map((skillPath) => {
      const skill = skillsByPath.get(skillPath);
      return { type: "skill", name: skill.name, path: skill.path };
    }),
  ];
}

function validatedTurnOptions(body, capabilities) {
  const model = capabilities.models.find((entry) => entry.id === body.model || entry.model === body.model);
  if (body.model && !model) throw new Error("Ce modèle n’est pas disponible sur ce Mac");
  const effort = body.effort || null;
  if (effort && model && !model.supportedReasoningEfforts.some((entry) => entry.effort === effort)) {
    throw new Error("Ce niveau de raisonnement n’est pas disponible pour ce modèle");
  }
  const collaborationMode = capabilities.collaborationModes.find((entry) => entry.name === body.collaborationMode);
  if (body.collaborationMode && !collaborationMode) {
    throw new Error("Ce mode de collaboration n’est pas disponible sur ce Mac");
  }
  return {
    model: model?.model || model?.id || null,
    effort,
    collaborationMode: collaborationMode ? {
      mode: collaborationMode.mode,
      settings: {
        model: collaborationMode.model,
        reasoning_effort: collaborationMode.reasoningEffort,
        developer_instructions: null,
      },
    } : null,
  };
}

async function loadCodexProjectRegistry() {
  let state;
  try {
    state = JSON.parse(await fs.readFile(codexStatePath, "utf8"));
  } catch (error) {
    throw new Error(`Impossible de lire les projets Codex : ${error.message}`);
  }

  const localProjects = state["local-projects"] || {};
  const order = Array.isArray(state["project-order"]) ? state["project-order"] : [];
  const threadOrders = state["sidebar-project-thread-orders"] || {};
  const assignments = state["thread-project-assignments"] || {};
  const projects = [];

  for (const id of order) {
    const source = localProjects[id];
    const cwd = source?.rootPaths?.[0];
    if (!source || typeof cwd !== "string" || !path.isAbsolute(cwd)) continue;
    let exists = false;
    try {
      exists = (await fs.stat(cwd)).isDirectory();
    } catch {}
    projects.push({
      id,
      cwd,
      name: source.name || path.basename(cwd),
      threadCount: 0,
      activeCount: 0,
      updatedAt: Number(source.updatedAt || source.createdAt || 0) / 1_000,
      preview: "",
      exists,
      isWorkspaceRoot: true,
      rootName: "Projet Codex",
    });
  }

  return { projects, assignments, threadOrders };
}

function projectIdForThread(thread, registry) {
  const assigned = registry.assignments[thread.id]?.projectId;
  if (assigned) return assigned;
  return registry.projects.find((project) => project.cwd === thread.cwd)?.id || null;
}

function annotateThreads(threads, registry) {
  return threads.map((thread) => ({
    ...thread,
    projectId: projectIdForThread(thread, registry),
  }));
}

async function readProjectThreads(codex, registry, projectId, cursor, limit) {
  const desktopActiveThreadIds = await readDesktopActiveThreadIds();
  const activeThreadIds = new Set([...desktopActiveThreadIds, ...codex.activeThreadIds]);
  const ordered = registry.threadOrders[projectId]?.threadIds;
  const storedThreadIds = Array.isArray(ordered)
    ? ordered
    : Object.entries(registry.assignments)
      .filter(([, assignment]) => assignment?.projectId === projectId)
      .map(([threadId]) => threadId);
  const threadIds = await excludeArchivedThreadIds(storedThreadIds);
  const offset = Math.max(0, Number(cursor || 0) || 0);
  const selectedIds = threadIds.slice(offset, offset + limit);
  const data = [];

  for (let index = 0; index < selectedIds.length; index += 16) {
    const batch = selectedIds.slice(index, index + 16);
    const results = await Promise.all(batch.map(async (threadId) => {
      try {
        const result = await codex.request("thread/read", { threadId, includeTurns: false }, 5_000);
        return result.thread || result;
      } catch {
        return null;
      }
    }));
    for (const thread of results) {
      if (thread?.id) data.push(withActivityStatus({ ...thread, projectId }, activeThreadIds));
    }
  }

  const nextOffset = offset + selectedIds.length;
  return {
    data,
    nextCursor: nextOffset < threadIds.length ? String(nextOffset) : null,
  };
}

async function aggregateProjects(codex, maxPages = 11) {
  const desktopActiveThreadIds = await readDesktopActiveThreadIds();
  const activeThreadIds = new Set([...desktopActiveThreadIds, ...codex.activeThreadIds]);
  const registry = await loadCodexProjectRegistry();
  const projects = new Map(registry.projects.map((project) => [project.id, { ...project }]));
  const projectThreads = new Map();
  const seenThreads = new Set();

  const indexThread = (thread) => {
    if (seenThreads.has(thread.id)) return true;
    seenThreads.add(thread.id);
    const projectId = projectIdForThread(thread, registry);
    const current = projects.get(projectId);
    if (!current) return false;
    const ids = projectThreads.get(projectId) || new Set();
    ids.add(thread.id);
    projectThreads.set(projectId, ids);
    current.threadCount = Math.max(current.threadCount, ids.size);
    if (thread.status?.type === "active" || activeThreadIds.has(thread.id)) current.activeCount += 1;
    current.updatedAt = Math.max(current.updatedAt, thread.updatedAt || thread.createdAt || 0);
    if (!current.preview) current.preview = thread.name || thread.preview || "";
    return false;
  };

  const scan = async (sourceKind) => {
    let cursor = null;
    let pages = 0;
    do {
      let result;
      try {
        result = await codex.request("thread/list", {
          cursor,
          limit: 200,
          sortKey: "recency_at",
          sortDirection: "desc",
          sourceKinds: [sourceKind],
          archived: false,
        }, 5_000);
      } catch {
        return false;
      }
      for (const thread of result.data || []) {
        indexThread(thread);
      }
      cursor = result.nextCursor || null;
      pages += 1;
    } while (cursor && pages < maxPages);
    return !cursor;
  };

  const completion = [];
  for (const sourceKind of ALL_THREAD_SOURCES) {
    completion.push({ sourceKind, complete: await scan(sourceKind) });
  }
  return {
    projects: registry.projects.map((project) => projects.get(project.id)),
    complete: completion.every((entry) => entry.complete),
    incompleteSources: completion.filter((entry) => !entry.complete).map((entry) => entry.sourceKind),
    indexedThreads: seenThreads.size,
  };
}

async function createBridge() {
  const config = await loadConfig();
  const migration = await migratePocketThreadSources();
  if (migration.migrated > 0) {
    process.stdout.write(`${JSON.stringify({ event: "threadSourceMigration", ...migration })}\n`);
  }
  const codex = new CodexAppServer();
  await codex.start();

  const server = http.createServer(async (request, response) => {
    const url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);

    if (request.method === "GET" && url.pathname === "/v1/health/public") {
      sendJSON(response, 200, { bridge: "ok", version: VERSION });
      return;
    }

    if (!isAuthorized(request, config)) {
      sendJSON(response, 401, { error: "unauthorized" });
      return;
    }

    try {
      if (request.method === "GET" && url.pathname === "/v1/health") {
        sendJSON(response, 200, {
          bridge: "ok",
          version: VERSION,
          codexReady: codex.ready,
          codexError: codex.lastError,
          deviceName: os.hostname(),
        });
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/events") {
        response.writeHead(200, {
          "content-type": "text/event-stream; charset=utf-8",
          "cache-control": "no-cache, no-transform",
          connection: "keep-alive",
          "x-accel-buffering": "no",
        });
        response.write(`data: ${JSON.stringify({ kind: "bridge", state: "connected" })}\n\n`);
        const unsubscribe = codex.subscribe((event) => {
          if (!response.destroyed) response.write(`data: ${JSON.stringify(event)}\n\n`);
        });
        const heartbeat = setInterval(() => {
          if (!response.destroyed) response.write(`: heartbeat\n\n`);
        }, 15_000);
        request.on("close", () => {
          clearInterval(heartbeat);
          unsubscribe();
        });
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/account") {
        const account = await codex.request("account/read", { refreshToken: false });
        let rateLimits = null;
        try {
          rateLimits = await codex.request("account/rateLimits/read", {});
        } catch {}
        sendJSON(response, 200, { ...account, rateLimits });
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/activity") {
        const desktopActiveThreadIds = await readDesktopActiveThreadIds();
        const activeThreadIds = new Set([...desktopActiveThreadIds, ...codex.activeThreadIds]);
        sendJSON(response, 200, { activeThreadIds: [...activeThreadIds].sort() });
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/capabilities") {
        const threadId = url.searchParams.get("threadId");
        if (!threadId) {
          sendJSON(response, 400, { error: "thread_id_required" });
          return;
        }
        sendJSON(response, 200, await capabilitiesFor(codex, config, threadId));
        return;
      }

      if (request.method === "POST" && url.pathname === "/v1/account/device-login") {
        const result = await codex.request("account/login/start", { type: "chatgptDeviceCode" });
        sendJSON(response, 200, result);
        return;
      }

      if (request.method === "POST" && url.pathname === "/v1/account/logout") {
        sendJSON(response, 200, await codex.request("account/logout", {}));
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/projects") {
        sendJSON(response, 200, await aggregateProjects(codex));
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/workspaces") {
        const registry = await loadCodexProjectRegistry();
        sendJSON(response, 200, { projects: registry.projects });
        return;
      }

      if (request.method === "GET" && url.pathname === "/v1/threads") {
        const archived = url.searchParams.get("archived") === "true";
        const limit = Math.min(Number(url.searchParams.get("limit") || 100), 200);
        const registry = await loadCodexProjectRegistry();
        const projectId = url.searchParams.get("projectId");
        if (projectId) {
          sendJSON(response, 200, await readProjectThreads(
            codex,
            registry,
            projectId,
            url.searchParams.get("cursor"),
            limit,
          ));
          return;
        }
        const result = await codex.request("thread/list", {
          cursor: url.searchParams.get("cursor"),
          limit,
          sortKey: "recency_at",
          sortDirection: "desc",
          sourceKinds: ALL_THREAD_SOURCES,
          archived,
          cwd: url.searchParams.get("cwd") || null,
          searchTerm: url.searchParams.get("search") || null,
        });
        const desktopActiveThreadIds = await readDesktopActiveThreadIds();
        const activeThreadIds = new Set([...desktopActiveThreadIds, ...codex.activeThreadIds]);
        sendJSON(response, 200, {
          ...result,
          data: annotateThreads(result.data || [], registry)
            .map((thread) => withActivityStatus(thread, activeThreadIds)),
        });
        return;
      }

      if (request.method === "POST" && url.pathname === "/v1/threads") {
        const body = await readJSON(request);
        const registry = await loadCodexProjectRegistry();
        const allowedRoots = [...config.allowedRoots, ...registry.projects.map((project) => project.cwd)];
        if (!safePath(body.cwd, allowedRoots)) {
          sendJSON(response, 400, { error: "cwd_not_allowed" });
          return;
        }
        const started = await codex.request("thread/start", {
          cwd: body.cwd,
          approvalPolicy: "on-request",
          sandbox: body.sandbox || "workspace-write",
          model: body.model || null,
          ephemeral: false,
          threadSource: "user",
        });
        if (typeof body.prompt === "string" && body.prompt.trim()) {
          const turn = await codex.request("turn/start", {
            threadId: started.thread.id,
            input: [{ type: "text", text: body.prompt.trim(), text_elements: [] }],
          });
          sendJSON(response, 201, { thread: started.thread, turn: turn.turn });
        } else {
          sendJSON(response, 201, started);
        }
        return;
      }

      let match = matchRoute(url.pathname, /^\/v1\/threads\/([^/]+)$/);
      if (request.method === "GET" && match) {
        const result = await codex.request("thread/read", { threadId: match[0], includeTurns: true });
        const desktopActiveThreadIds = await readDesktopActiveThreadIds();
        const activeThreadIds = new Set([...desktopActiveThreadIds, ...codex.activeThreadIds]);
        sendJSON(response, 200, {
          ...result,
          thread: withActivityStatus(result.thread || result, activeThreadIds),
        });
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/threads\/([^/]+)\/turns$/);
      if (request.method === "POST" && match) {
        const body = await readJSON(request);
        if (typeof body.text !== "string" || !body.text.trim()) {
          sendJSON(response, 400, { error: "text_required" });
          return;
        }
        const capabilities = await capabilitiesFor(codex, config, match[0]);
        const input = buildTurnInput(body, capabilities);
        const options = validatedTurnOptions(body, capabilities);
        const requestedActiveTurnId = body.expectedTurnId || codex.activeTurnIds.get(match[0]) || null;
        const desktopActiveThreadIds = await readDesktopActiveThreadIds();
        const shouldSteerDesktop = Boolean(requestedActiveTurnId || desktopActiveThreadIds.has(match[0]));
        const clientUserMessageId = typeof body.clientRequestId === "string" ? body.clientRequestId : null;
        const desktopDelivery = await codex.desktopIPC.forwardTurn(match[0], {
          input,
          model: options.model,
          effort: options.effort,
          collaborationMode: options.collaborationMode,
          clientUserMessageId,
        }, { steer: shouldSteerDesktop });
        if (desktopDelivery.handled) {
          const routed = desktopDelivery.result || {};
          const routedTurn = routed.turn || (routed.turnId ? {
            id: routed.turnId,
            status: "inProgress",
            items: [],
          } : null);
          const turn = codex.trackDesktopTurn(match[0], routedTurn || {
            id: requestedActiveTurnId || clientUserMessageId || randomUUID(),
            status: "inProgress",
            items: [],
          });
          codex.broadcast({ kind: "desktopSync", threadId: match[0], state: "owner-routed" });
          sendJSON(response, 202, {
            ...routed,
            turn,
            delivery: shouldSteerDesktop ? "desktop-steered" : "desktop-started",
            clientRequestId: body.clientRequestId || null,
          });
          return;
        }
        const resumed = await codex.request("thread/resume", {
          threadId: match[0],
          model: options.model,
        });
        const resumedThread = resumed.thread || resumed;
        let activeTurnId = body.expectedTurnId
          || codex.activeTurnIds.get(match[0])
          || activeTurnIdFromThread(resumedThread);
        if (!activeTurnId) {
          const read = await codex.request("thread/read", { threadId: match[0], includeTurns: true }, 8_000);
          activeTurnId = activeTurnIdFromThread(read.thread || read);
        }

        if (activeTurnId) {
          const steered = await codex.request("turn/steer", {
            threadId: match[0],
            expectedTurnId: activeTurnId,
            input,
          });
          codex.activeThreadIds.add(match[0]);
          codex.activeTurnIds.set(match[0], steered.turnId || activeTurnId);
          sendJSON(response, 202, {
            turn: { id: steered.turnId || activeTurnId, status: "inProgress", items: [] },
            delivery: "steered",
            clientRequestId: body.clientRequestId || null,
          });
          return;
        }

        const result = await codex.request("turn/start", {
          threadId: match[0],
          input,
          model: options.model,
          effort: options.effort,
          collaborationMode: options.collaborationMode,
          clientUserMessageId,
        });
        if (result.turn?.id) {
          codex.activeThreadIds.add(match[0]);
          codex.activeTurnIds.set(match[0], result.turn.id);
        }
        sendJSON(response, 202, {
          ...result,
          delivery: "started",
          clientRequestId: body.clientRequestId || null,
        });
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/threads\/([^/]+)\/steer$/);
      if (request.method === "POST" && match) {
        const body = await readJSON(request);
        sendJSON(response, 202, await codex.request("turn/steer", {
          threadId: match[0],
          expectedTurnId: body.expectedTurnId,
          input: [{ type: "text", text: body.text, text_elements: [] }],
        }));
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/threads\/([^/]+)\/interrupt$/);
      if (request.method === "POST" && match) {
        const body = await readJSON(request);
        sendJSON(response, 200, await codex.request("turn/interrupt", {
          threadId: match[0],
          turnId: body.turnId,
        }));
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/threads\/([^/]+)\/name$/);
      if (request.method === "POST" && match) {
        const body = await readJSON(request);
        sendJSON(response, 200, await codex.request("thread/name/set", { threadId: match[0], name: body.name }));
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/threads\/([^/]+)\/archive$/);
      if (request.method === "POST" && match) {
        sendJSON(response, 200, await codex.request("thread/archive", { threadId: match[0] }));
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/favorites\/([^/]+)$/);
      if (request.method === "PUT" && match) {
        if (!config.favorites.includes(match[0])) config.favorites.push(match[0]);
        await fs.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
        sendJSON(response, 200, { favorites: config.favorites });
        return;
      }
      if (request.method === "DELETE" && match) {
        config.favorites = config.favorites.filter((id) => id !== match[0]);
        await fs.writeFile(configPath, `${JSON.stringify(config, null, 2)}\n`, { mode: 0o600 });
        sendJSON(response, 200, { favorites: config.favorites });
        return;
      }
      if (request.method === "GET" && url.pathname === "/v1/favorites") {
        sendJSON(response, 200, { favorites: config.favorites });
        return;
      }

      match = matchRoute(url.pathname, /^\/v1\/approvals\/([^/]+)$/);
      if (request.method === "POST" && match) {
        const body = await readJSON(request);
        const original = codex.serverRequests.get(String(match[0]));
        if (!original) {
          sendJSON(response, 409, { error: "approval_not_pending" });
          return;
        }
        let result;
        if (original.method === "item/commandExecution/requestApproval" || original.method === "item/fileChange/requestApproval") {
          result = { decision: body.decision };
        } else if (original.method === "tool/requestUserInput") {
          result = { answers: body.answers || {} };
        } else {
          result = body.result || {};
        }
        codex.respond(match[0], result);
        sendJSON(response, 200, { accepted: true });
        return;
      }

      sendJSON(response, 404, { error: "not_found" });
    } catch (error) {
      sendJSON(response, 500, {
        error: "bridge_error",
        message: error.message,
        details: error.details || null,
      });
    }
  });

  await new Promise((resolve, reject) => {
    server.once("error", reject);
    server.listen(config.port, config.bindHost, resolve);
  });
  const address = server.address();
  const actualPort = typeof address === "object" && address ? address.port : config.port;
  process.stdout.write(`${JSON.stringify({ event: "listening", host: config.bindHost, port: actualPort, configPath })}\n`);

  let orphanWatchdog;
  const close = () => {
    clearInterval(orphanWatchdog);
    codex.stop();
    server.close(() => process.exit(0));
  };
  const parentPid = process.ppid;
  orphanWatchdog = setInterval(() => {
    if (process.ppid === 1 || process.ppid !== parentPid) close();
  }, 1_000);
  orphanWatchdog.unref();
  process.on("SIGINT", close);
  process.on("SIGTERM", close);
  return { server, codex, config, port: actualPort };
}

createBridge().catch((error) => {
  process.stderr.write(`${error.stack || error.message}\n`);
  process.exit(1);
});
